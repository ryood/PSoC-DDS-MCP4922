/*******************************************************************************
* File Name: Sampling_Clock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Sampling_Clock_H)
#define CY_CLOCK_Sampling_Clock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void Sampling_Clock_StartEx(uint32 alignClkDiv);
#define Sampling_Clock_Start() \
    Sampling_Clock_StartEx(Sampling_Clock__PA_DIV_ID)

#else

void Sampling_Clock_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void Sampling_Clock_Stop(void);

void Sampling_Clock_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 Sampling_Clock_GetDividerRegister(void);
uint8  Sampling_Clock_GetFractionalDividerRegister(void);

#define Sampling_Clock_Enable()                         Sampling_Clock_Start()
#define Sampling_Clock_Disable()                        Sampling_Clock_Stop()
#define Sampling_Clock_SetDividerRegister(clkDivider, reset)  \
    Sampling_Clock_SetFractionalDividerRegister((clkDivider), 0u)
#define Sampling_Clock_SetDivider(clkDivider)           Sampling_Clock_SetDividerRegister((clkDivider), 1u)
#define Sampling_Clock_SetDividerValue(clkDivider)      Sampling_Clock_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define Sampling_Clock_DIV_ID     Sampling_Clock__DIV_ID

#define Sampling_Clock_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define Sampling_Clock_CTRL_REG   (*(reg32 *)Sampling_Clock__CTRL_REGISTER)
#define Sampling_Clock_DIV_REG    (*(reg32 *)Sampling_Clock__DIV_REGISTER)

#define Sampling_Clock_CMD_DIV_SHIFT          (0u)
#define Sampling_Clock_CMD_PA_DIV_SHIFT       (8u)
#define Sampling_Clock_CMD_DISABLE_SHIFT      (30u)
#define Sampling_Clock_CMD_ENABLE_SHIFT       (31u)

#define Sampling_Clock_CMD_DISABLE_MASK       ((uint32)((uint32)1u << Sampling_Clock_CMD_DISABLE_SHIFT))
#define Sampling_Clock_CMD_ENABLE_MASK        ((uint32)((uint32)1u << Sampling_Clock_CMD_ENABLE_SHIFT))

#define Sampling_Clock_DIV_FRAC_MASK  (0x000000F8u)
#define Sampling_Clock_DIV_FRAC_SHIFT (3u)
#define Sampling_Clock_DIV_INT_MASK   (0xFFFFFF00u)
#define Sampling_Clock_DIV_INT_SHIFT  (8u)

#else 

#define Sampling_Clock_DIV_REG        (*(reg32 *)Sampling_Clock__REGISTER)
#define Sampling_Clock_ENABLE_REG     Sampling_Clock_DIV_REG
#define Sampling_Clock_DIV_FRAC_MASK  Sampling_Clock__FRAC_MASK
#define Sampling_Clock_DIV_FRAC_SHIFT (16u)
#define Sampling_Clock_DIV_INT_MASK   Sampling_Clock__DIVIDER_MASK
#define Sampling_Clock_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_Sampling_Clock_H) */

/* [] END OF FILE */
