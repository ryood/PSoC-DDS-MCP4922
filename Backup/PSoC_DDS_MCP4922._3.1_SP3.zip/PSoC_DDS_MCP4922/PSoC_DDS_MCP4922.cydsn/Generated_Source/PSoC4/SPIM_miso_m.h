/*******************************************************************************
* File Name: SPIM_miso_m.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SPIM_miso_m_H) /* Pins SPIM_miso_m_H */
#define CY_PINS_SPIM_miso_m_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SPIM_miso_m_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SPIM_miso_m_Write(uint8 value) ;
void    SPIM_miso_m_SetDriveMode(uint8 mode) ;
uint8   SPIM_miso_m_ReadDataReg(void) ;
uint8   SPIM_miso_m_Read(void) ;
uint8   SPIM_miso_m_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SPIM_miso_m_DRIVE_MODE_BITS        (3)
#define SPIM_miso_m_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SPIM_miso_m_DRIVE_MODE_BITS))

#define SPIM_miso_m_DM_ALG_HIZ         (0x00u)
#define SPIM_miso_m_DM_DIG_HIZ         (0x01u)
#define SPIM_miso_m_DM_RES_UP          (0x02u)
#define SPIM_miso_m_DM_RES_DWN         (0x03u)
#define SPIM_miso_m_DM_OD_LO           (0x04u)
#define SPIM_miso_m_DM_OD_HI           (0x05u)
#define SPIM_miso_m_DM_STRONG          (0x06u)
#define SPIM_miso_m_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define SPIM_miso_m_MASK               SPIM_miso_m__MASK
#define SPIM_miso_m_SHIFT              SPIM_miso_m__SHIFT
#define SPIM_miso_m_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SPIM_miso_m_PS                     (* (reg32 *) SPIM_miso_m__PS)
/* Port Configuration */
#define SPIM_miso_m_PC                     (* (reg32 *) SPIM_miso_m__PC)
/* Data Register */
#define SPIM_miso_m_DR                     (* (reg32 *) SPIM_miso_m__DR)
/* Input Buffer Disable Override */
#define SPIM_miso_m_INP_DIS                (* (reg32 *) SPIM_miso_m__PC2)


#if defined(SPIM_miso_m__INTSTAT)  /* Interrupt Registers */

    #define SPIM_miso_m_INTSTAT                (* (reg32 *) SPIM_miso_m__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define SPIM_miso_m_DRIVE_MODE_SHIFT       (0x00u)
#define SPIM_miso_m_DRIVE_MODE_MASK        (0x07u << SPIM_miso_m_DRIVE_MODE_SHIFT)


#endif /* End Pins SPIM_miso_m_H */


/* [] END OF FILE */
