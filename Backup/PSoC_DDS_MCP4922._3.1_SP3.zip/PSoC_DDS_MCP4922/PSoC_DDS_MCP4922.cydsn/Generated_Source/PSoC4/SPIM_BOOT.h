/*******************************************************************************
* File Name: SPIM_BOOT.h
* Version 2.0
*
* Description:
*  This file provides constants and parameter values for the bootloader
*  communication interface of SCB component.
*
* Note:
*
********************************************************************************
* Copyright 2014, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_BOOT_SPIM_H)
#define CY_SCB_BOOT_SPIM_H

#include "SPIM_PVT.h"

#if (SPIM_SCB_MODE_I2C_INC)
    #include "SPIM_I2C.h"
#endif /* (SPIM_SCB_MODE_I2C_INC) */

#if (SPIM_SCB_MODE_EZI2C_INC)
    #include "SPIM_EZI2C.h"
#endif /* (SPIM_SCB_MODE_EZI2C_INC) */

#if (SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC)
    #include "SPIM_SPI_UART.h"
#endif /* (SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC) */


/***************************************
*        Function Prototypes
***************************************/

/* Bootloader communication interface enable */
#define SPIM_BTLDR_COMM_ENABLED ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SPIM) || \
                                             (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

#if (SPIM_SCB_MODE_I2C_INC)

    #define SPIM_I2C_BTLDR_COMM_ENABLED     (SPIM_BTLDR_COMM_ENABLED && \
                                                            (SPIM_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             SPIM_I2C_SLAVE_CONST))

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_I2C_BTLDR_COMM_ENABLED)
    /* Bootloader physical layer functions */
    void SPIM_I2CCyBtldrCommStart(void);
    void SPIM_I2CCyBtldrCommStop (void);
    void SPIM_I2CCyBtldrCommReset(void);
    cystatus SPIM_I2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus SPIM_I2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Size of Read/Write buffers for I2C bootloader  */
    #define SPIM_I2C_BTLDR_SIZEOF_READ_BUFFER   (64u)
    #define SPIM_I2C_BTLDR_SIZEOF_WRITE_BUFFER  (64u)
    #define SPIM_I2C_MIN_UINT16(a, b)           ( ((uint16)(a) < (uint16) (b)) ? \
                                                                    ((uint32) (a)) : ((uint32) (b)) )
    #define SPIM_WAIT_1_MS                      (1u)
#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_I2C_BTLDR_COMM_ENABLED) */

#endif /* (SPIM_SCB_MODE_I2C_INC) */


#if (SPIM_SCB_MODE_EZI2C_INC)

    /* Provide EMPTY bootloader communication functions. EZI2C is NOT supported yet */
    #define SPIM_EZI2C_BTLDR_COMM_ENABLED   (SPIM_BTLDR_COMM_ENABLED && \
                                                         SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_EZI2C_BTLDR_COMM_ENABLED)
    /* Bootloader physical layer functions */
    void SPIM_EzI2CCyBtldrCommStart(void);
    void SPIM_EzI2CCyBtldrCommStop (void);
    void SPIM_EzI2CCyBtldrCommReset(void);
    cystatus SPIM_EzI2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus SPIM_EzI2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_EZI2C_BTLDR_COMM_ENABLED) */

#endif /* (SPIM_SCB_MODE_EZI2C_INC) */

#if (SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC)
    /* Provide EMPTY bootloader communication functions. SPI and UART is NOT supported yet */
    #define SPIM_SPI_BTLDR_COMM_ENABLED     (SPIM_BTLDR_COMM_ENABLED && \
                                                        SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

    #define SPIM_UART_BTLDR_COMM_ENABLED    (SPIM_BTLDR_COMM_ENABLED && \
                                                        SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_SPI_BTLDR_COMM_ENABLED)
    /* SPI Bootloader physical layer functions */
    void SPIM_SpiCyBtldrCommStart(void);
    void SPIM_SpiCyBtldrCommStop (void);
    void SPIM_SpiCyBtldrCommReset(void);
    cystatus SPIM_SpiCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus SPIM_SpiCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_SPI_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_UART_BTLDR_COMM_ENABLED)
    /* UART Bootloader physical layer functions */
    void SPIM_UartCyBtldrCommStart(void);
    void SPIM_UartCyBtldrCommStop (void);
    void SPIM_UartCyBtldrCommReset(void);
    cystatus SPIM_UartCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus SPIM_UartCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_UART_BTLDR_COMM_ENABLED) */

#endif /* (SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC) */

#if !defined (SPIM_I2C_BTLDR_COMM_ENABLED)
    #define SPIM_I2C_BTLDR_COMM_ENABLED     (0u)
#endif /* (SPIM_I2C_BTLDR_COMM_ENABLED) */

#if !defined (SPIM_EZI2C_BTLDR_COMM_ENABLED)
    #define SPIM_EZI2C_BTLDR_COMM_ENABLED   (0u)
#endif /* (SPIM_EZI2C_BTLDR_COMM_ENABLED) */

#if !defined (SPIM_SPI_BTLDR_COMM_ENABLED)
    #define SPIM_SPI_BTLDR_COMM_ENABLED     (0u)
#endif /* (SPIM_SPI_BTLDR_COMM_ENABLED) */

#if !defined (SPIM_UART_BTLDR_COMM_ENABLED)
    #define SPIM_UART_BTLDR_COMM_ENABLED    (0u)
#endif /* (SPIM_UART_BTLDR_COMM_ENABLED) */

/* Bootloader enabled condition for each mode */
#define SPIM_BTLDR_COMM_MODE_ENABLED    (SPIM_I2C_BTLDR_COMM_ENABLED   || \
                                                     SPIM_EZI2C_BTLDR_COMM_ENABLED || \
                                                     SPIM_SPI_BTLDR_COMM_ENABLED   || \
                                                     SPIM_UART_BTLDR_COMM_ENABLED)

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_BTLDR_COMM_ENABLED)
    #if (SPIM_BTLDR_COMM_MODE_ENABLED)
        /* Bootloader physical layer functions */
        void SPIM_CyBtldrCommStart(void);
        void SPIM_CyBtldrCommStop (void);
        void SPIM_CyBtldrCommReset(void);
        cystatus SPIM_CyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
        cystatus SPIM_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    #endif /* (SPIM_BTLDR_COMM_MODE_ENABLED) */

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SPIM)
        #define CyBtldrCommStart    SPIM_CyBtldrCommStart
        #define CyBtldrCommStop     SPIM_CyBtldrCommStop
        #define CyBtldrCommReset    SPIM_CyBtldrCommReset
        #define CyBtldrCommWrite    SPIM_CyBtldrCommWrite
        #define CyBtldrCommRead     SPIM_CyBtldrCommRead
    #endif /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SPIM) */
#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_BTLDR_COMM_ENABLED) */

#endif /* (CY_SCB_BOOT_SPIM_H) */

/* [] END OF FILE */
